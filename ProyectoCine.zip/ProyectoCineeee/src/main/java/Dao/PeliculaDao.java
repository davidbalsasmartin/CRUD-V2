package Dao;

import java.io.IOException;
import java.io.Serializable;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import conexion.CierraProcesos;
import tabla.Evento;
import tabla.Pelicula;

public class PeliculaDao implements InterfazDao<Pelicula>, Serializable {
    
  private static final long serialVersionUID = -2453940261427218094L;
	private static final String SeleccionaPeliculaCons = "SELECT nompeli, codpeli, despeli FROM peliula order by 2";
	private static final String ActualizaPeliculaCons = "UPDATE peliula SET nompeli= ?, despeli= ?  WHERE codpeli= ?";
	private static final String InsertaPeliculaCons = "INSERT INTO peliula (nompeli, despeli) VALUES ( ?, ?)";
	private static final String EliminaPeliculaCons = "DELETE FROM peliula WHERE codpeli= ?";


	private Connection con = null;

	public PeliculaDao(Connection con) {
		super();
		this.con = con;
	}

	/**
	 * Devuelte ArrayList con todas las Peliculas
	 * 
	 * @return ArrayList<Pelicula>
	 */
	public ArrayList<Pelicula> lista() {
		System.out.println("Iniciando seleccionaPelicula");
		PreparedStatement seleccionarPelicula = null;
		ArrayList<Pelicula> select = new ArrayList<Pelicula>();
		ResultSet filtrar = null;
		try {
			seleccionarPelicula = this.con.prepareStatement(SeleccionaPeliculaCons);
			filtrar = seleccionarPelicula.executeQuery();
			if (filtrar != null) {
				while (filtrar.next()) {
					Pelicula PeliculaDos = new Pelicula();
					PeliculaDos = whileNext(filtrar, PeliculaDos);

					select.add(PeliculaDos);
				}
			} else {
				System.out.println("Error al realizar seleccionaPelicula");
			}

		} catch (SQLException e) {
			System.out.println(e.getMessage());
		} finally {
			CierraProcesos.cerrarPreparedStatement(seleccionarPelicula);
			CierraProcesos.cerrarResultSet(filtrar);
		}
		System.out.println("Finalizando seleccionaPelicula");
		return select;
	}

	/**
	 * Modifica un Pelicula
	 * 
	 * @param uno
	 */
    public void modifica(Pelicula uno) {
      System.out.println("Iniciando actualizarPelicula");
      PreparedStatement actualizaPelicula = null;
      Pelicula PeliculaDos = new Pelicula();
      
      try {
        actualizaPelicula = this.con.prepareStatement(ActualizaPeliculaCons);
        System.out.println("Iniciando actualizaPelicula");
        actualizaPelicula.setString(1, uno.getNomPelicula());
        actualizaPelicula.setString(2, uno.getDesPelicula());
        actualizaPelicula.setInt(3, uno.getCodPelicula());
  
        int filas = actualizaPelicula.executeUpdate();
  
        if (filas == 0) {
          System.out.println("Error al realizar actualizaPelicula");
        }
      } catch (SQLException e) {
        System.out.println(e.getMessage());
      } finally {
        CierraProcesos.cerrarPreparedStatement(actualizaPelicula);
      }
      System.out.println("Finalizando actualizaPelicula");
    }

	/**
	 * Inserta un Pelicula
	 * 
	 * @param uno
	 */
	public void inserta(Pelicula uno) {
		System.out.println("Iniciando insertaPelicula");
		PreparedStatement insertarPelicula = null;
		try {

			insertarPelicula = con.prepareStatement(InsertaPeliculaCons);
			insertarPelicula.setString(1, uno.getNomPelicula());
			insertarPelicula.setString(2, uno.getDesPelicula());

			int filas = insertarPelicula.executeUpdate();
			if (filas == 0) {
				System.out.println("Error al realizar insertaPelicula");
			}

		} catch (SQLException e) { // TODO Auto-generated catch block
			System.out.println(e.getMessage());
		} finally {
			CierraProcesos.cerrarPreparedStatement(insertarPelicula);

		}
		System.out.println("Saliendo insertaPelicula");
		

	}

	/**
	 * Borra un Pelicula
	 * 
	 * @param i
	 */
	public void borra(int i) {
		
		System.out.println("Iniciando borraPelicula");
		PreparedStatement deletePeli = null;
		try {
			deletePeli = con.prepareStatement(EliminaPeliculaCons);
			deletePeli.setInt(1, i);
			System.out.println("Pelicula " + i + " eliminada.");

			int filas = deletePeli.executeUpdate();

			if (filas == 0) {
				System.out.println("Error al realizar borraPelicula");
			} 
		} catch (SQLException e) {
			System.out.println(e.getMessage());
		} finally {
			CierraProcesos.cerrarPreparedStatement(deletePeli);
		}
		System.out.println("Finalizando borraPelicula");
		
	}

	/**
	 * 
	 * @param filtra
	 * @param Pelicula
	 * @return Pelicula
	 */
	private Pelicula whileNext(ResultSet filtra, Pelicula Pelicula) {
		try {
			Pelicula.setCodPelicula(filtra.getInt("codPeli"));
			Pelicula.setNomPelicula(filtra.getString("nomPeli"));
			Pelicula.setDesPelicula(filtra.getString("desPeli"));

		} catch (SQLException e) {
			System.out.println(e.getMessage());
		}
		return Pelicula;
	}

}
