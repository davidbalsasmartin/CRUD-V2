package Dao;

import java.io.Serializable;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import conexion.CierraProcesos;
import tabla.Evento;

public class EventoDao implements InterfazDao<Evento>, Serializable {

  private static final long serialVersionUID = -2453940261427218094L;
  private static final String InsertaEvenCons = "INSERT INTO evento (ciudad, fecpeli, lugar, codpelicula) VALUES (?, ?, ?, ? )";
	private static final String ActualizaEvenCons = "UPDATE evento SET ciudad = ?, fecpeli = ?, lugar = ?, codpelicula = ? where codevento= ?";
	private static final String SeleccionaEvenCons = "select codevento, codpelicula, fecpeli, ciudad, lugar from evento";
	private static final String EliminaEvenCons = "DELETE FROM evento WHERE codevento= ?";

	private Connection con = null;

	public EventoDao(Connection con) {
		super();
		this.con = con;
	}

	/**
	 * Devuelve un ArrayList de todos los Eventos
	 * 
	 * @return ArrayList<Evento>
	 */
	public ArrayList<Evento> lista() {
		System.out.println("Iniciando seleccionaEven");
		PreparedStatement seleccionarEven = null;
		ArrayList<Evento> select = new ArrayList<Evento>();
		ResultSet filtrar = null;
		try {

			seleccionarEven = this.con.prepareStatement(SeleccionaEvenCons);
			filtrar = seleccionarEven.executeQuery();
			if (filtrar != null) {
				while (filtrar.next()) {
					Evento evenDos = new Evento();
					evenDos = whileNext(filtrar, evenDos);
					select.add(evenDos);
				}
			} else {
				System.out.println("Error al seleccionar los eventos");
			}
		} catch (SQLException e) {
			System.out.println(e.getMessage());
		} finally {
			CierraProcesos.cerrarPreparedStatement(seleccionarEven);
			CierraProcesos.cerrarResultSet(filtrar);
		}
		System.out.println("Finalizando seleccionaEven");
		return select;
	}

	/**
	 * Modifica un Evento
	 * 
	 * @param uno
	 */
	public void modifica(Evento uno) {
		System.out.println("Iniciando actualizarEven");
		PreparedStatement actualizaEven = null;

		try {
			actualizaEven = this.con.prepareStatement(ActualizaEvenCons);
			actualizaEven.setString(1, uno.getCiudad());
			actualizaEven.setDate(2, uno.getFecPeli());
			actualizaEven.setString(3, uno.getLugar());
			actualizaEven.setInt(4, uno.getPeli());
			actualizaEven.setInt(5, uno.getcodEvento());

			int filas = actualizaEven.executeUpdate();
			if (filas == 0) {
				System.out.println("Error, no hay filas afectadas");
			}
		} catch (SQLException e) {
			System.out.println(e.getMessage());
		} finally {
			CierraProcesos.cerrarPreparedStatement(actualizaEven);
		}
		System.out.println("Finalizando actualizarEven");


	}

	/**
	 * Inserta un Evento
	 * 
	 * @param uno
	 */
	public void inserta(Evento uno) {
		System.out.println("Iniciando insertaEven");
		PreparedStatement insertarEvento = null;

		try {
			insertarEvento = con.prepareStatement(InsertaEvenCons);
			insertarEvento.setString(1, uno.getCiudad());
			insertarEvento.setDate(2, uno.getFecPeli());
			insertarEvento.setString(3, uno.getLugar());
			insertarEvento.setInt(4, uno.getPeli());

			int filas = insertarEvento.executeUpdate();
			if (filas == 0) {
				System.out.println("Error, no hay filas afectadas");
			}
		} catch (SQLException e) {
			System.out.println(e.getMessage());
		} finally {
			CierraProcesos.cerrarPreparedStatement(insertarEvento);

		}
		System.out.println("Finalizando insertaEven");


	}

	/**
	 * Borra un Evento
	 * 
	 * @param i
	 */
	public void borra(int i) {

		PreparedStatement deleteEven = null;
		try {
			deleteEven = con.prepareStatement(EliminaEvenCons);
			deleteEven.setInt(1, i);
			int filas = deleteEven.executeUpdate();
			if (filas == 0) {
				System.out.println("Error, no hay filas afectadas");
			}
		} catch (SQLException e) {
			System.out.println(e.getMessage());
		} finally {
			CierraProcesos.cerrarPreparedStatement(deleteEven);
		}


	}

	/**
	 * 
	 * @param filtra
	 * @param even
	 * @return Evento
	 */
	private Evento whileNext(ResultSet filtra, Evento even) {
		try {
		  even.setcodEvento(filtra.getInt("codevento"));
		  even.setPeli(filtra.getInt("codpelicula"));
		  even.setCiudad(filtra.getString("ciudad"));
		  even.setLugar(filtra.getString("lugar"));
		  even.setFecPeli(filtra.getDate("fecpeli"));
		} catch (SQLException e) {
			System.out.println(e.getMessage());
		}
		return even;
	}

}
