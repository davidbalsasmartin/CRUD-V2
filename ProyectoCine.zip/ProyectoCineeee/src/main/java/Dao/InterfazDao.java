package Dao;

import java.util.ArrayList;

public interface InterfazDao <T> {
	 ArrayList<T> lista ();
	 void modifica (T uno);
	 void inserta (T uno);
	 void borra (int i);
}
