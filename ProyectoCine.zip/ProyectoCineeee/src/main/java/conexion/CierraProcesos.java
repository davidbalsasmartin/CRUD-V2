package conexion;

import java.io.Serializable;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public abstract class CierraProcesos implements Serializable {

  private static final long serialVersionUID = -2217152997311996649L;

  public CierraProcesos() {
	}
	
	/**
	 * Cierra ResultSet
	 * @param r
	 */
	public static void cerrarResultSet(ResultSet r) {

		try {
			if (r instanceof ResultSet) {
				((ResultSet) r).close();
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	
	/**
	 * Cierra PreparedStatement
	 * @param p
	 */
	public static void cerrarPreparedStatement(PreparedStatement p) {

		try {
			if (p instanceof PreparedStatement) {
				((PreparedStatement) p).close();
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	/**
	 * Cierra Statement
	 * @param s
	 */
	public static void cerrarStatement(Statement s) {

		try {
			if (s instanceof Statement) {
				((Statement) s).close();
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	
	/**
	 * Cierra Connection
	 * @param con
	 */
	public static void cerrarConexion(Connection con) {

		try {
			con.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
}
