package conexion;

import java.io.Serializable;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class Conexion implements Serializable {


  private static final long serialVersionUID = 8189242870795941935L;
  private static String driverName = "com.mysql.jdbc.Driver";
	private static String username = "root";
	private static String password = "";
	private static String sourceURL = "jdbc:mysql://localhost:3306/crudcine";
	private static Connection con;

	/**
	 * Crea Connection
	 * 
	 * @return con
	 */
	public static Connection getConnection() {
		try {
			Class.forName(driverName);
			try {
				con = DriverManager.getConnection(sourceURL, username, password);
			} catch (SQLException ex) {
				System.out.println("Fallo de conexi�n.");
			}
		} catch (ClassNotFoundException ex) {
			System.out.println("No se encuentra el Drive.");
		}
		return con;
	}

}
