package tabla;

import java.io.IOException;
import java.io.Serializable;
import java.sql.Date;

public class Evento implements Serializable {

  private static final long serialVersionUID = -5432291290986496209L;

  private int codEvento;
  private int peli;
  private String lugar;
  private String ciudad;
  private Date fecPeli;

  public Evento(int peli, String lugar, String ciudad, Date fecPeli) {
    super();
    this.peli = peli;
    this.lugar = lugar;
    this.ciudad = ciudad;
    this.fecPeli = fecPeli;
  }

  public Evento() {

  }

  @Override
  public String toString() {
    return "Evento [codEvento=" + codEvento + ", Peli=" + peli + ", lugar=" + lugar + ", ciudad="
        + ciudad + ", fecPeli=" + fecPeli + "]";
  }

  public int getcodEvento() {
    return codEvento;
  }

  public void setcodEvento(int codEvento) {
    this.codEvento = codEvento;
  }

  public int getPeli() {
    return peli;
  }

  public void setPeli(int peli) {
    this.peli = peli;
  }

  public String getLugar() {
    return lugar;
  }

  public void setLugar(String lugar) {
    this.lugar = lugar;
  }

  public String getCiudad() {
    return ciudad;
  }

  public void setCiudad(String ciudad) {
    this.ciudad = ciudad;
  }

  public Date getFecPeli() {
    return fecPeli;
  }

  public void setFecPeli(Date fecPeli) {
    this.fecPeli = fecPeli;
  }

}
