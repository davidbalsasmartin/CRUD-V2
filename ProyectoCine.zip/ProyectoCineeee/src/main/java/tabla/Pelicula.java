package tabla;
import java.io.IOException;
import java.io.Serializable;
import java.sql.Date;
import java.util.ArrayList;

public class Pelicula implements Serializable {

  private static final long serialVersionUID = -5432291290986496209L; 

	
	private int codPelicula;
	private String nomPelicula;
	private String desPelicula;
	
	public Pelicula(String nomPelicula, String desPelicula) {
		super();
		this.nomPelicula = nomPelicula;
		this.desPelicula = desPelicula;
	}
	
	@Override
	public String toString() {
		return "Pelicula [codPelicula=" + codPelicula + ", nomPelicula=" + nomPelicula + ", desPelicula=" + desPelicula + "]";
	}

	public Pelicula() {
	}


	public int getCodPelicula() {
		return codPelicula;
	}


	public void setCodPelicula(int codPelicula) {
		this.codPelicula = codPelicula;
	}


	public String getNomPelicula() {
		return nomPelicula;
	}


	public void setNomPelicula(String nomPelicula) {
		this.nomPelicula = nomPelicula;
	}


	public String getDesPelicula() {
		return desPelicula;
	}


	public void setDesPelicula(String desPelicula) {
		this.desPelicula = desPelicula;
	}
	
}
