package miServlets.principal;

import java.sql.Date;
import java.util.HashMap;
import java.util.Map;
import javax.servlet.http.HttpServlet;
import tabla.Evento;
import tabla.Pelicula;

public class ServletPrincipal extends HttpServlet {

	private static final long serialVersionUID = -4930573893895680160L;
	public final static String codigo = "codigo";
	public final static String nombre = "nombre";
	public final static String descripcion = "descripcion";
	public final static String peli = "peli";
	public final static String lugar = "lugar";
	public final static String ciudad = "ciudad";
	public final static String fecha = "fecha";

	/**
	 * Valida los campos de un formulario
	 * 
	 * @param m
	 * @return ArrayList<String>
	 */
	public static Map<String, String> validar(Map<String, String[]> m) {

		Map<String, String> errores = new HashMap<String, String>();

		// Comprueba que nombre sea correcto
		if (m.containsKey(nombre) && !errores.containsKey(nombre)) {
			if (m.get(nombre)[0].isEmpty() || (m.get(nombre)[0].length() < 3)
					|| (m.get(nombre)[0].length()) > 30) {
				errores.put(nombre, nombre);
			}
		}
		
		// Comprueba que descripcion sea correcto
		if (m.containsKey(descripcion) && !errores.containsKey(descripcion)) {
			if ((m.get(descripcion)[0].length() < 3) || (m.get(descripcion)[0].length()) > 60) {
				errores.put(descripcion, descripcion);
			}
		}

		// Comprueba que ciudad sea correcto
		if (m.containsKey(ciudad) && !errores.containsKey(ciudad)) {
			if (m.get(ciudad)[0].matches("^.*\\d.*$") || (m.get(ciudad)[0].isEmpty())
					|| (m.get(ciudad)[0].length() < 3) || (m.get(ciudad)[0].length()) > 20) {
				errores.put(ciudad, ciudad);
			}
		}

		// Comprueba que lugar sea correcto
        if (m.containsKey(lugar) && !errores.containsKey(lugar)) {
            if ((m.get(lugar)[0].isEmpty()) || (m.get(lugar)[0].length() < 3) || (m.get(lugar)[0].length()) > 20) {
                errores.put(lugar, lugar);
            }
        }
		
		// Comprueba que c�digo es un dato entero
		if (m.containsKey(codigo) && !errores.containsKey(codigo)) {
			if ((m.get(codigo)[0].length() > 4) || (m.get(codigo)[0].isEmpty())) {
				errores.put(codigo, codigo);
			} else {
				try {
					Integer.valueOf(m.get(codigo)[0]);
				} catch (Exception e) {
					errores.put(codigo, codigo);
				}
			}
		}
		// Comprueba que peli (codigo de pelicula en evento) es un dato entero
        if (m.containsKey(peli) && !errores.containsKey(peli)) {
            if ((m.get(peli)[0].length() > 4) || (m.get(peli)[0].isEmpty())) {
                errores.put(peli, peli);
            } else {
                try {
                    Integer.valueOf(m.get(peli)[0]);
                } catch (Exception e) {
                    errores.put(peli, peli);
                }
            }
        }

		// Comprueba Fecha
		if (m.containsKey(fecha) && !errores.containsKey(fecha)) {
			if (m.get(fecha)[0].isEmpty()) {
				errores.put(fecha, fecha);
			} else {
				try {
					Date.valueOf(m.get(fecha)[0]);
					if (Date.valueOf(m.get(fecha)[0]).before(Date.valueOf("2015-01-01"))
							|| Date.valueOf(m.get(fecha)[0]).after(Date.valueOf("2030-01-01"))) {
						errores.put(fecha, fecha);
					}
				} catch (Exception e) {
					errores.put(fecha, fecha);
				}
			}
		}

		return errores;
	}

	/**
	 * Devuelve una pelicula a partir de un mapa
	 * 
	 * @param mapPeli
	 * @return Pelicula
	 */
	public static Pelicula creaPelicula(Map<String, String[]> mapPeli) {
		Pelicula dos = new Pelicula(mapPeli.get(nombre)[0], mapPeli.get(descripcion)[0]);
		return dos;
	}
	
	/**
	 * Devuelve un evento a partir de un mapa
	 * 
	 * @param mapEven
	 * @return Evento
	 */
	public static Evento creaEvento(Map<String, String[]> mapEven) {
	  
		Evento dos = new Evento(Integer.valueOf(mapEven.get(peli)[0]), mapEven.get(lugar)[0], mapEven.get(ciudad)[0], Date.valueOf(mapEven.get(fecha)[0]));
		return dos;
	}

}
