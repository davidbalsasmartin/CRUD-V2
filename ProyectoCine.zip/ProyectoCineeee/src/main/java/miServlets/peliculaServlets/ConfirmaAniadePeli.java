package miServlets.peliculaServlets;

import java.io.IOException;
import java.sql.Connection;
import java.sql.Date;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import Dao.PeliculaDao;
import conexion.CierraProcesos;
import conexion.Conexion;
import miServlets.principal.ServletPrincipal;
import tabla.Pelicula;

@WebServlet("/confirmar_nueva_pelicula")

public class ConfirmaAniadePeli extends ServletPrincipal {

	private static final long serialVersionUID = -7632981578013048985L;

	@Override
	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}

	@Override
	public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		Connection con = Conexion.getConnection();
		Map<String, String> errores = validar(request.getParameterMap());

		if (errores.size() == 0) {
      System.out.println("comfirmaaniadealu iniciado");
			Pelicula PeliculaDos = creaPelicula(request.getParameterMap());
			PeliculaDao peli = new PeliculaDao(con);
			peli.inserta(PeliculaDos);
			request.setAttribute("peliculas", peli.lista());
			request.getRequestDispatcher("/WEB-INF/jsp/listaPelicula.jsp").forward(request, response);
			
		} else {
			request.setAttribute("conservar", request.getParameterMap());
			request.setAttribute("errores", errores);
			request.getRequestDispatcher("/WEB-INF/jsp/anadirPelicula.jsp").forward(request, response);
		}

		CierraProcesos.cerrarConexion(con);

	}
}