package miServlets.eventoServlets;

import java.io.IOException;
import java.sql.Connection;
import java.util.Map;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import Dao.EventoDao;
import Dao.PeliculaDao;
import conexion.CierraProcesos;
import conexion.Conexion;
import miServlets.principal.ServletPrincipal;
import tabla.Evento;

@WebServlet("/confirmar_nuevo_evento")

public class ConfirmaAniadeEven extends ServletPrincipal {

	private static final long serialVersionUID = -7632981578013048985L;

	@Override
	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}

	@Override
	public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		Connection con = Conexion.getConnection();
		Map<String, String> errores = validar(request.getParameterMap());

		if (errores.size() == 0) {
			EventoDao evento = new EventoDao(con);
			Evento eventoUno = creaEvento(request.getParameterMap());
			evento.inserta(eventoUno);
			request.setAttribute("eventos", evento.lista());
			request.getRequestDispatcher("/WEB-INF/jsp/listaEvento.jsp").forward(request, response);

		} else {
			
			PeliculaDao pelicula = new PeliculaDao(con);
			request.setAttribute("peliculas", pelicula.lista());
			request.setAttribute("conservar", request.getParameterMap());
			request.setAttribute("errores", errores);
			request.getRequestDispatcher("/WEB-INF/jsp/anadirEvento.jsp").forward(request, response);
		}
		CierraProcesos.cerrarConexion(con);
	}
}