package miServlets.eventoServlets;

import java.io.IOException;
import java.sql.Connection;
import java.util.HashMap;
import java.util.Map;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import Dao.EventoDao;
import Dao.PeliculaDao;
import conexion.CierraProcesos;
import conexion.Conexion;
import miServlets.principal.ServletPrincipal;
import tabla.Evento;

@WebServlet("/edita_evento")
public class EditaEven extends ServletPrincipal {

	private static final long serialVersionUID = -7632981578013048985L;

	@Override
	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		doPost(request, response);
	}

	@Override
	public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		Connection con = Conexion.getConnection();
		PeliculaDao peliculas = new PeliculaDao(con);

		request.setAttribute("conservar", request.getParameterMap());
		request.setAttribute("peliculas", peliculas.lista());
		request.getRequestDispatcher("/WEB-INF/jsp/modificaEvento.jsp").forward(request, response);

		CierraProcesos.cerrarConexion(con);
	}
}