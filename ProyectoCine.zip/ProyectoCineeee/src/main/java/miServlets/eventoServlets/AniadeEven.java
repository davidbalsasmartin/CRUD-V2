package miServlets.eventoServlets;

import java.io.IOException;
import java.sql.Connection;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import Dao.PeliculaDao;
import conexion.CierraProcesos;
import conexion.Conexion;
import miServlets.principal.ServletPrincipal;

@WebServlet("/nuevo_evento")
public class AniadeEven extends ServletPrincipal {

	private static final long serialVersionUID = -7632981578013048985L;

	@Override
	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		doPost(request, response);
	}

	@Override
	public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
    System.out.println("YA LLEG� AL PUTO SERVLET DE LOS HUEVOS ANIADEEVEN");
		Connection con = Conexion.getConnection();
		PeliculaDao peliUno = new PeliculaDao(con);
		request.setAttribute("peliculas", peliUno.lista());
		request.getRequestDispatcher("/WEB-INF/jsp/anadirEvento.jsp").forward(request, response);
		CierraProcesos.cerrarConexion(con);

	}
}