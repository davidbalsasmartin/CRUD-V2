package miServlets.eventoServlets;

import java.io.IOException;
import java.sql.Connection;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import Dao.EventoDao;
import conexion.CierraProcesos;
import conexion.Conexion;
import miServlets.principal.ServletPrincipal;

@WebServlet("/eventos")

public class ListaEven extends ServletPrincipal {

	private static final long serialVersionUID = -7632981578013048985L;

	@Override
	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}

	@Override
	public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		Connection con = Conexion.getConnection();
		EventoDao evento = new EventoDao(con);
		
		request.setAttribute("eventos", evento.lista());
		request.getRequestDispatcher("/WEB-INF/jsp/listaEvento.jsp").forward(request, response);
		CierraProcesos.cerrarConexion(con);
	}
}