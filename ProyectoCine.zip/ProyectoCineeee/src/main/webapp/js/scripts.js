/**
 * 
 */

function activar() {
	document.getElementById("pelicula2").classList.add('active');
	document.getElementById("pelicula2").style.color = "#4285f4";
}
function desactivar() {
	if (document.getElementById('materialFormCardPeliEx').value == "") {
		document.getElementById('pelicula2').classList.remove('active');
		document.getElementById("pelicula2").style.color = "grey";
	} else {
		document.getElementById("pelicula2").style.color = "grey";

	}
}
function select() {
	if (document.getElementById('materialFormCardPeliEx').value.length != 0) {
		activar();
		desactivar();
	}
}

function modifica(tabla, id) {

	var table = document.getElementById("listado");
	var p = new Array();

	for (var e = 0; e < table.rows[0].cells.length - 1; e++) {
		p[table.rows[0].cells[e].id] = table.rows[id].cells[e].innerText;
		}
	post(tabla, p);
}

function post(tabla, p) {

	var form = document.createElement("form");
	form.setAttribute("method", "post");
	if (tabla == "p") {
		form.setAttribute("action", "edita_pelicula");
	} else if (tabla == "e") {
		form.setAttribute("action", "edita_evento");
	}

	for ( var key in p) {
		if (p.hasOwnProperty(key)) {
			var hiddenField = document.createElement("input");
			hiddenField.setAttribute("type", "hidden");
			hiddenField.setAttribute("name", key);
			hiddenField.setAttribute("value", p[key]);

			form.appendChild(hiddenField);
		}
	}

	document.body.appendChild(form);
	form.submit();
}

function borra(persona, identificador) {

	var table = document.getElementById("listado");
	var p = new String();

	p = table.rows[identificador].cells[0].innerText;

	formulario = document.createElement("form");
	formulario.setAttribute("method", "post");
	if (persona == "p") {
		formulario.setAttribute("action", "borrar_pelicula");
	} else if (persona == "e") {
		formulario.setAttribute("action", "borrar_evento");
	}

	var hiddenField = document.createElement("input");
	hiddenField.setAttribute("type", "hidden");
	hiddenField.setAttribute("name", "codigo");
	hiddenField.setAttribute("value", p);

	formulario.appendChild(hiddenField);

	document.body.appendChild(formulario);

	document.getElementById("insertaModal").innerHTML = p;
}

function enviaForm() {
	formulario.submit();
}
